import java.net.Socket;
import java.nio.ByteBuffer;
import java.sql.SQLException;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.NullPointerException;

public class ClientHandler implements Runnable {
	public User client = new User();
  public DBHandler DB = new DBHandler();
  public int DBresult, stop = 0;
  public String resultado;
  ClientHandler(Socket clientSocket) {
    client.socket = clientSocket;
  } 
  
  public void run()  {
	//Communication initializer
      try{
       client.in = new BufferedReader(new InputStreamReader(client.socket.getInputStream()));
       client.out = new PrintWriter(client.socket.getOutputStream(), true);
      } catch (IOException e) {
        //System.out.println("Read failed");
        System.exit(-1);

      }
      
      while(true) {
      try{
      switch(client.in.readLine()) {
        case("2"): {
          client.pass = client.in.readLine();
          this.DBresult = DB.updatePass(client);
          
          if (this.DBresult == 1)
        	  client.out.println("1");
          else
        	  client.out.println("0");
          break;
        }
      	case("3"): {
      		System.out.println( "Entrou no case 3");
      	  client.fullName = client.in.readLine();
      	  System.out.println( "fullname"+client.fullName);
      	  client.birth = client.in.readLine();
      	 System.out.println( "birth"+client.birth);
      	  client.address = client.in.readLine();
      	 System.out.println( "address"+client.address);
      	  client.driver = client.in.readLine();
      	System.out.println( "driver"+client.driver);
      	  this.DBresult = DB.updateProfile(client);
      	  
          if (this.DBresult == 1)
        	  client.out.println("1");
          else
        	  client.out.println("0");
          break;
        }
      	case("1"): {
      		System.out.println("entriu no login");
            client.email = client.in.readLine();
            client.pass = client.in.readLine();
            this.DBresult = DB.select(client);
            DB.getId(client);
            
            if (this.DBresult == 1) {
          	  client.out.println("1");
          	  System.out.println("antes do exist");
              File img = new File("C:\\Users\\Afonso\\Desktop\\Eclipse\\eclipse\\EasyCV_sv\\images\\"+client.ID+".jpg");
        	  client.out.println("1");
        	  this.resultado=client.in.readLine();
        	  if(resultado.equals("10")) { //request {
        		client.sendIMG(client, img);
        		System.out.println("Send img to client");
        		client.out.println("1");
        	  }
            }
        	  if (this.DBresult == 0) 
        		  client.out.println("0");
        	  break;    
            }          
            
       case("0"): {
          client.email = client.in.readLine();
          client.pass = client.in.readLine();
          this.DBresult = DB.insert(client);
          System.out.print(this.DBresult);
          
          if (this.DBresult == 1)
        	  client.out.println("1");
          else
        	  client.out.println("0");
          break;
       }
       case("4"): {
           client.email = client.in.readLine();
           this.DBresult = DB.updateEmail(client);
           
           if (this.DBresult == 1)
         	  client.out.println("1");
           else
         	  client.out.println("0");
           break;
         }
       case("5"): {
            client.email = client.in.readLine();
            this.DBresult = DB.updateEmail(client);
            client.pass = client.in.readLine();       
            this.DBresult = DB.updatePass(client);
            
            if (this.DBresult == 1)
          	  client.out.println("1");
            else
          	  client.out.println("0");
            break;
          }
       
       case("6"): {

          DB.select_allusers(client);
          break;
         }
       case("7"): {
    	   System.out.println("Entrei no case");
    	   while(stop == 0) {
    	   switch(client.in.readLine()) {
    	   	case("0"):{
    	   		client.birthPlace = client.in.readLine();
    	   		break;
    	   	}
    	   	case("1"):{
    	   		client.sports = client.in.readLine();
    	   		break;
    	   	}
    	   	case("2"):{
    	   		client.hobbies = client.in.readLine();
    	   		break;
    	   	}
    	   	case("3"):{
    	   		client.phone = client.in.readLine();
    	   		break;
    	   	}
    	   	case("4"):{
    	   		client.goodAt = client.in.readLine();
    	   		break;
    	   	}
    	   	case("5"):{
    	   		client.likeMost = client.in.readLine();
    	   		break;
    	   	}
    	   	case("6"):{
    	   		client.civilState = client.in.readLine();
    	   		break;
    	   	}
    	   	case("7"):{
    	   		System.out.println("Entrei no case 7");
    	   		DB.update(client);
    	   		stop = 1;
    	   		break;
    	   	}
    	   }
    	   }
       }
       case("8"): {
    	   InputStream inputStream = client.socket.getInputStream();
           byte[] sizeAr = new byte[4];
           inputStream.read(sizeAr);
           int size = ByteBuffer.wrap(sizeAr).asIntBuffer().get();

           byte[] imageAr = new byte[size];
           inputStream.read(imageAr);
           
           

           BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageAr));

           System.out.println("Received " + image.getHeight() + "x" + image.getWidth() + ": " + System.currentTimeMillis());
           ImageIO.write(image, "jpg", new File("images/"+client.ID+".jpg"));
    	    
       }
       default: {
    	  break;
       }
      }
    }
      catch (IOException | SQLException | IllegalArgumentException | NullPointerException e) {
       // System.out.println("Session end");
        try {
			client.finalize();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
      }
    }
  }
   
}
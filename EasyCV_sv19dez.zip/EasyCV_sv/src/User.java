import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.nio.ByteBuffer;

import javax.imageio.ImageIO;

import org.omg.CORBA.portable.OutputStream;

public class User {

	public Socket socket = new Socket();
	public String email = new String();
	public String pass = new String();
	public int ID = -1;
	public BufferedReader in;
    public PrintWriter out;
    public String fullName = new String();
    public String birth = new String();
    public String address = new String();
    public String driver = new String();
    public String birthPlace = new String();
    public String sports = new String();
    public String hobbies = new String();
    public String phone = new String();
    public String goodAt = new String();
    public String likeMost = new String();
    public String civilState = new String();

    
    public void finalize() throws IOException {
    	
    	//System.out.println("User disconected.");
    	this.socket.close();
    	this.in.close();
    	this.out.close();
    }
    
    public void sendIMG(User client, File file) throws IOException {
		if (file.exists()){
		client.out.println("1");	
		java.io.OutputStream outputStream =  socket.getOutputStream();

        BufferedImage image = ImageIO.read(file);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ImageIO.write(image, "jpg", byteArrayOutputStream);

        byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
        outputStream.write(size);
        outputStream.write(byteArrayOutputStream.toByteArray());
		}
		else
			System.out.println("Ficheiro n�o existe");
		    client.out.println("10");
	}
}

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBHandler {

	public static String dbHost;
    public static Connection con;
    public static Statement stmt;
    public static ResultSet rs;
    public static String result;
    
    //DB Connection
    public DBHandler(){
    	
        try{
          dbHost = "jdbc:postgresql://dbm.fe.up.pt:5432/";
          String dbName = "sibd1809";
          String dbPass = "sibdsql";
          con = DriverManager.getConnection(dbHost,dbName,dbPass);
          stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
          stmt.executeUpdate("SET SCHEMA 'LPRO'");
        }
        catch (SQLException e) {
          System.out.println("Database failure");
          System.exit(-1);
        }
    }

    
    //Chaves primarias / MD5
    public int insert(User client) throws SQLException {
    	
    	String username = new String();
    	String passHash = getMd5(client.pass);
    	String SQL = "SELECT * FROM users WHERE username = '"+ client.email +"' AND password = '" + passHash + "'";
    	rs = stmt.executeQuery(SQL);
    	
    	while (rs.next()) {
            username = rs.getString("username");
        }
    	
    	System.out.println("Da DB veio "+username);
    	
    	if (username.length()>0)
    		return 0;
    	else {
    		SQL = "INSERT INTO users VALUES (DEFAULT,'" + client.email + "', md5('" + client.pass + "'));";
        	stmt.executeUpdate(SQL);
        	getId(client);
        	SQL = "INSERT INTO forms VALUES ('"+client.ID+"');";
        	stmt.executeUpdate(SQL);
        	return 1;
    	}
    }
    
    public int select(User client) throws SQLException {

    	
    	String username = new String();
    	String password = new String();
    	String passHash = getMd5(client.pass);
    	String SQL = "SELECT * FROM users WHERE username = '"+ client.email +"' AND password = '" + passHash + "';";
    	System.out.println(passHash);
        rs = stmt.executeQuery(SQL);
        
        while (rs.next()) {
            username = rs.getString("username");
            password = rs.getString("password");
        }
        
        System.out.println("Da DB veio "+username+" e "+password);
        
        if (username.contentEquals(client.email) && password.contentEquals(passHash))
          	return 1;
        else
           	return 0;
    }
    
	public int update(User client) throws SQLException {
		
		if (client.phone.length()< 1)
			client.phone = null;
		String SQL = "UPDATE forms SET fullname = '"+client.fullName+"', birth = '"+client.birth+"', address = '"+client.address+"', driver = '"+client.driver+"', birthplace = '"+client.birthPlace+"', sports = '"+client.sports+"', hobbies = '"+client.hobbies+"', phone = '"+client.phone+"', goodat = '"+client.goodAt+"', likemost = '"+client.likeMost+"', civilstate = '"+client.civilState+"' WHERE id IN ( SELECT id FROM users WHERE username = '"+client.email+"')";
		stmt.executeUpdate(SQL);
		return 1;
	}
	
	public int updateProfile(User client) throws SQLException {
		
		String SQL = "UPDATE forms SET fullname = '"+client.fullName+"', birth = '"+client.birth+"', address = '"+client.address+"', driver = '"+client.driver+"'WHERE id IN ( SELECT id FROM users WHERE username = '"+client.email+"')";
		stmt.executeUpdate(SQL);
		return 1;
	}
	
	public int updatePass(User client) throws SQLException {
		
		String SQL = "UPDATE users SET password = md5('"+client.pass+"') WHERE username = '"+client.email+"'";
		stmt.executeUpdate(SQL);
		return 1;
	}
	
	public int updateEmail(User client) throws SQLException {
		
		String SQL = "UPDATE users SET username = '"+client.email+"' WHERE password = md5('"+client.pass+"')";
		stmt.executeUpdate(SQL);
		return 1;
	}
	
	public void select_allusers(User client) throws SQLException {

		String SQL = "SELECT username from users";
		rs = stmt.executeQuery(SQL);
		String username;
		while (rs.next()) {
			username=rs.getString("username");
			client.out.println(username);
			}	
		client.out.println("0"); // a informa��o acaba com um 0 para do lado do cliente se saber quando � que acabou a listagem
	}

	public static String getMd5(String input) 
	  { 
	      try { 

	          // Static getInstance method is called with hashing MD5 
	          MessageDigest md = MessageDigest.getInstance("MD5"); 

	          // digest() method is called to calculate message digest 
	          //  of an input digest() return array of byte 
	          byte[] messageDigest = md.digest(input.getBytes()); 

	          // Convert byte array into signum representation 
	          BigInteger no = new BigInteger(1, messageDigest); 

	          // Convert message digest into hex value 
	          String hashtext = no.toString(16); 
	          while (hashtext.length() < 32) { 
	              hashtext = "0" + hashtext; 
	          } 
	          return hashtext; 
	      }  

	      // For specifying wrong message digest algorithms 
	      catch (NoSuchAlgorithmException e) { 
	          throw new RuntimeException(e); 
	      } 
	  }

	public void getId(User client) throws SQLException {
		
		String SQL = "SELECT id from users WHERE username = '"+client.email+"'";
		rs = stmt.executeQuery(SQL);
		while (rs.next()) {
			client.ID=rs.getInt("id");
			System.out.println(client.ID);
			}
	}
}

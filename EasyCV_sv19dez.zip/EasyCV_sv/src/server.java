import java.io.*;
import java.sql.SQLException;
import java.net.*;

public class server {

    private static ServerSocket server;
    private static Thread thread;
    private static ClientHandler newClient;
 

    public static void main(String args[]) throws SQLException{
    	
    	  //Socket initializer
          try{
        	  server = new ServerSocket(4469);
        	  System.out.println("Server is open.");
        	  
          } catch (IOException e) {
        	  System.out.println("Could not listen on port 4469");
        	  System.exit(-1);
          }
          
          
          //Waiting for client connection         
          try{
        	  while(true){
        		  
        		  newClient = new ClientHandler(server.accept());
        		  thread = new Thread(newClient);
        		  thread.start();
        		  System.out.println("Client connected.");  
        	  }
          }
          catch (IOException e) {
        		  System.out.println("Accept failed: 4469");
        		  System.exit(-1);
          }
     }
}

